<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/ssr-win.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0cba01_15035147',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '408475eba2a414f7ffc140c000763d78424af5d4' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/ssr-win.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0cba01_15035147 (Smarty_Internal_Template $_smarty_tpl) {
?>## 下载软件

![](/images/c_win_1.png)

## 导入节点

解压客户端，双击shadowsocksr4.0的客户端(打不开就用2.0，2.0打不开请下载安装net.framework3.0，还打不开麻烦升级到win7)

### 方法一：

1. 在快速添加节点中找到【备用节点导入方法】
2. 点击其中的链接

![](/images/c_win_2.png)

4. 找到系统托盘菜单中的SSR纸飞机图标右键调出菜单
5. 点击剪贴板批量导入ssr://链接

![](/images/c_win_3.png)

### 方法二(推荐)：

1.  在快速添加节点中找到节点订阅地址
2.  点击按钮复制订阅链接

![](/images/c_win_4.png)

1. 找到系统托盘菜单中的SSR纸飞机图标右键调出菜单
2. 打开SSR服务器订阅链接设置

![](/images/c_win_5.png)

7. 点击add添加一个订阅，将复制的链接填入右侧框内点击确定

![](/images/c_win_6.png)

9. 找到系统托盘菜单中的SSR纸飞机图标右键调出菜单
10. 点击更新SSR服务器订阅(不通过代理)

![](/images/c_win_7.png)

## 选择节点

1.  找到系统托盘菜单中的SSR纸飞机图标右键调出菜单
2.  服务器->找到对应本站的节点组->选择一个节点单击

![](/images/c_win_8.png)

4. 打开浏览器输入www.google.com试试吧！

以上教程均为电脑没有安装过任何代理软件的步骤，如果安装过其他代理软件可能产生冲突<?php }
}
