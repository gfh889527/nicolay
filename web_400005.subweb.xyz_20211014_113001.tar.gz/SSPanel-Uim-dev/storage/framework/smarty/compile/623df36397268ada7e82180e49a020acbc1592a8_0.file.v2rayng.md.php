<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/v2rayng.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0df0d7_57606139',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '623df36397268ada7e82180e49a020acbc1592a8' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/v2rayng.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0df0d7_57606139 (Smarty_Internal_Template $_smarty_tpl) {
?>1. 下载 V2RayNG 并安装
2. 点击左上角菜单按钮展开菜单->订阅设置->点击右上角“+”，URL填写以下地址并点击右上角“√”保存
3. 回到软件主界面->点击右上角“更多”按钮->更新订阅
4. 选择一个节点，点击右下角按钮订阅
<?php }
}
