<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/ssr-android.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0d1f55_21583009',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'be4c5796b5aa8cf1818567196a7e9787ee85b099' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/ssr-android.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0d1f55_21583009 (Smarty_Internal_Template $_smarty_tpl) {
?>1：下载app

![](/images/c_android_1.jpg)

2：添加订阅并更新

![](/images/c_android_2.jpg)

![](/images/c_android_3.jpg)

![](/images/c_android_4.jpg)

![](/images/c_android_5.jpg)

3：选择一个节点并设置路由

![](/images/c_android_6.jpg)

![](/images/c_android_7.jpg)

4：连接

![](/images/c_android_8.jpg)

注释：国产安卓系统为定制系统，如需要Youtube、Google套件等，需要安装Google框架，具体机型如何安装各不相同，请直接查找教程<?php }
}
