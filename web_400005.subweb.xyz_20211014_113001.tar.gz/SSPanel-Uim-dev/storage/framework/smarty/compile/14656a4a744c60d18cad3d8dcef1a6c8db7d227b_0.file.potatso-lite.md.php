<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/potatso-lite.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0d67a0_54455705',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '14656a4a744c60d18cad3d8dcef1a6c8db7d227b' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/potatso-lite.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0d67a0_54455705 (Smarty_Internal_Template $_smarty_tpl) {
?>1. 在外服APP商店中搜索Potatso Lite下载，安装时如果弹出登录框则使用上方的账户
2. 打开 Potatso Lite，点击添加代理，选择“订阅”，名字任意填写，点击复制本网页下方的“订阅地址”，粘贴到URL中，点击右上角的 √
3. 选择一个代理节点，点击下方的“开始”即可
<?php }
}
