<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/electron-ssr.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0d0681_03791005',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '789255a3b22eddd5ee208c6bb6e52810adbf8a86' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/electron-ssr.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0d0681_03791005 (Smarty_Internal_Template $_smarty_tpl) {
?>1. 自行安装python，下载 electron-ssr 安装并启动
2. 右击托盘纸飞机图标->服务器->订阅管理，点击“添加”，输入订阅地址并回车
3. 订阅成功后点击“完成”关闭界面，右击托盘纸飞机图标->服务器，选择一个节点即可<?php }
}
