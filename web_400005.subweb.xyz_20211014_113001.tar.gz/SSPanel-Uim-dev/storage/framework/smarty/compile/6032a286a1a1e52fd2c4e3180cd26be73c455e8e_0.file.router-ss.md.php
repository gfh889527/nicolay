<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/router-ss.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0dc303_88058279',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6032a286a1a1e52fd2c4e3180cd26be73c455e8e' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/router-ss.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0dc303_88058279 (Smarty_Internal_Template $_smarty_tpl) {
?>梅林：

1. 下载“科学上网”插件
2. 进入路由器管理页面->系统管理->勾选“Format JFFS partition at next boot”和“Enable JFFS custom scripts and configs”->应用本页面设置，重启路由器
3. 进入路由器管理页面->软件中心->离线安装，上传插件文件进行安装
4. 进入“科学上网”插件->节点管理，手动添加节点，打开“科学上网”开关->保存&应用

padavan：

1. 进入路由器管理页面->扩展功能->Shadowsocks
2. 手动添加需要的节点并勾选->应用主SS->打开上方的开关<?php }
}
