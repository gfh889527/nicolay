<?php
/* Smarty version 3.1.39, created on 2021-10-12 17:24:33
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/dialog.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6165545123aae8_79483995',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0a83c69b4ab45661b784d0d47046fb79b8417af7' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/dialog.tpl',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6165545123aae8_79483995 (Smarty_Internal_Template $_smarty_tpl) {
?><div aria-hidden="true" class="modal modal-va-middle fade" id="result" role="dialog" tabindex="-1">
    <div class="modal-dialog modal-xs">
        <div class="modal-content">
            <div class="modal-inner">
                <p class="h5 margin-top-sm text-black-hint" id="msg"></p>
            </div>
            <div class="modal-footer">
                <p class="text-right">
                    <button class="btn btn-flat btn-brand-accent waves-attach" data-dismiss="modal" type="button"
                            id="result_ok">知道了
                    </button>
                </p>
            </div>
        </div>
    </div>
</div><?php }
}
