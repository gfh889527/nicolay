<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/v2rayn.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0dda06_31040093',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '61f49e8bc1db990211b9313c38723f9a7a41eff0' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/v2rayn.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0dda06_31040093 (Smarty_Internal_Template $_smarty_tpl) {
?>1. 下载 V2RayN，解压至任意磁盘并运行
2. 双击任务栏右下角V2RayN图标->订阅->订阅设置->添加->填入下方的地址，点击确定
3. 再次点击订阅->更新订阅，右击任务栏右下角V2RayN图标->启动Http代理
4. 自行选择“Http代理模式”和“服务器”
<?php }
}
