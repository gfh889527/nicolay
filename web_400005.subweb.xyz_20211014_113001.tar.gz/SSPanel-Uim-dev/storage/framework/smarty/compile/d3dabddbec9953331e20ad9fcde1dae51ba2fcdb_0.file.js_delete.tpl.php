<?php
/* Smarty version 3.1.39, created on 2021-10-12 17:38:02
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/table/js_delete.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6165577a631df2_67668811',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd3dabddbec9953331e20ad9fcde1dae51ba2fcdb' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/table/js_delete.tpl',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6165577a631df2_67668811 (Smarty_Internal_Template $_smarty_tpl) {
?>table_1
.row('#row_1_' + deleteid)
.remove()
.draw();
<?php }
}
