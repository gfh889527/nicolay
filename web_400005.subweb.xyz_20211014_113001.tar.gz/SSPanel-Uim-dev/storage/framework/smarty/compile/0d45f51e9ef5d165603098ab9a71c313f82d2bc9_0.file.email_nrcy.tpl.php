<?php
/* Smarty version 3.1.39, created on 2021-10-12 17:24:50
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/email_nrcy.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616554624c68d6_45105205',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0d45f51e9ef5d165603098ab9a71c313f82d2bc9' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/email_nrcy.tpl',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616554624c68d6_45105205 (Smarty_Internal_Template $_smarty_tpl) {
?><ul>
    <img src="/images/email_nrcy.jpg" height="458" width="468">
    <br/>
    <?php if ($_smarty_tpl->tpl_vars['config']->value['enable_admin_contact'] === true) {?>
        <p>如果发现“收信查询”中没有找到邮件，请联系管理员：</p>
        <?php if ($_smarty_tpl->tpl_vars['config']->value['admin_contact1'] != '') {?>
            <li><?php echo $_smarty_tpl->tpl_vars['config']->value['admin_contact1'];?>
</li>
        <?php }?>
        <?php if ($_smarty_tpl->tpl_vars['config']->value['admin_contact2'] != '') {?>
            <li><?php echo $_smarty_tpl->tpl_vars['config']->value['admin_contact2'];?>
</li>
        <?php }?>
        <?php if ($_smarty_tpl->tpl_vars['config']->value['admin_contact3'] != '') {?>
            <li><?php echo $_smarty_tpl->tpl_vars['config']->value['admin_contact3'];?>
</li>
        <?php }?>
    <?php }?>
</ul><?php }
}
