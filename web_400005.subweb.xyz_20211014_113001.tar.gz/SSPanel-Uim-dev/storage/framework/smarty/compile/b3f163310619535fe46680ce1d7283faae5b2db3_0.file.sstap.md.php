<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/sstap.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0cd720_63038104',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b3f163310619535fe46680ce1d7283faae5b2db3' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/sstap.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0cd720_63038104 (Smarty_Internal_Template $_smarty_tpl) {
?>1. 安装 SSTap
2. 期间会安装虚拟网卡，请点击允许或确认
3. 打开桌面程序SSTap
4. 齿轮图标-SSR订阅-SSR订阅管理添加以下订阅链接即可
5. 更新后选择其中一个节点闪电图标测试节点-测试UDP转发...通过!（UDP通过即可连接并开始游戏），如测试不通过，点击齿轮图标设置DNS，推荐谷歌DNS
<?php }
}
