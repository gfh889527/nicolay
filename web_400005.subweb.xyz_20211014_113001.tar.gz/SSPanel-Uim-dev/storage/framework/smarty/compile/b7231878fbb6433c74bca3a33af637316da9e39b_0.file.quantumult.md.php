<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/quantumult.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0d39b2_52790123',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b7231878fbb6433c74bca3a33af637316da9e39b' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/quantumult.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0d39b2_52790123 (Smarty_Internal_Template $_smarty_tpl) {
?>1. 使用共享账户登录 App Store （请勿在“设置”界面直接登录AppleID），搜索并下载“Quantumult”，期间可能会弹出付款，照做即可，不会产生真实扣费
2. 点击下方的“设置”，点击“订阅”，点击右上角的 + 号，选择“服务器”，“名称”任意填写，点击复制本网页下方的“订阅地址”，粘贴到“链接”中，点击右上角的“保存”
3. 点击 Quantumult 底部菜单栏中间的图标，选择一个节点，再点击“主页”，打开右上角的开关即可
<?php }
}
