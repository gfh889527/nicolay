<?php
/* Smarty version 3.1.39, created on 2021-10-12 17:24:33
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/auth/telegram.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6165545124c8f5_90848184',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '21de8aeeb79b08b58efc4975965920c03a4340ef' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/auth/telegram.tpl',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6165545124c8f5_90848184 (Smarty_Internal_Template $_smarty_tpl) {
if ($_smarty_tpl->tpl_vars['config']->value['enable_telegram'] === true) {?>
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/gh/davidshimjs/qrcodejs@gh-pages/qrcode.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
>
        var telegram_qrcode = 'mod://login/<?php echo $_smarty_tpl->tpl_vars['login_token']->value;?>
';
        var qrcode = new QRCode(document.getElementById("telegram-qr"));
        qrcode.clear();
        qrcode.makeCode(telegram_qrcode);
    <?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
>
        var flag = false;
        $(document).ready(function () {
            $("#calltgauth").click(
                    function () {
                        if(flag == false){
                            f();
                            flag = true;
                        }else{
                            return 0;
                        }
                    }
            );

            function f() {
                $.ajax({
                    type: "POST",
                    url: "qrcode_check",
                    dataType: "json",
                    data: {
                        token: "<?php echo $_smarty_tpl->tpl_vars['login_token']->value;?>
",
                        number: "<?php echo $_smarty_tpl->tpl_vars['login_number']->value;?>
"
                    },
                    success: (data) => {
                        if (data.ret > 0) {
                            clearTimeout(tid);

                            $.ajax({
                                type: "POST",
                                url: "/auth/qrcode_login",
                                dataType: "json",
                                data: {
                                    token: "<?php echo $_smarty_tpl->tpl_vars['login_token']->value;?>
",
                                    number: "<?php echo $_smarty_tpl->tpl_vars['login_number']->value;?>
"
                                },
                                success: (data) => {
                                    if (data.ret) {
                                        $("#result").modal();
                                        $$.getElementById('msg').innerHTML = '登录成功！';
                                        window.setTimeout("location.href=/user/", <?php echo $_smarty_tpl->tpl_vars['config']->value['jump_delay'];?>
);
                                    }
                                },
                                error: (jqXHR) => {
                                    $("#result").modal();
                                    $$.getElementById('msg').innerHTML = `发生错误：${
                                            jqXHR.status
                                            }`;
                                }
                            });

                        } else {
                            if (data.ret === -1) {
                                $('#telegram-qr').replaceWith('此二维码已经过期，请刷新页面后重试。');
                                $('#code_number').replaceWith('<code id="code_number">此数字已经过期，请刷新页面后重试。</code>');
                            }
                        }
                    },
                    error: (jqXHR) => {
                        if (jqXHR.status !== 200 && jqXHR.status !== 0) {
                            $("#result").modal();
                            $$.getElementById('msg').innerHTML = `发生错误：${
                                    jqXHR.status
                                    }`;
                        }
                    }
                });
                tid = setTimeout(f, 2500); //循环调用触发setTimeout
            }


        })
    <?php echo '</script'; ?>
>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['config']->value['enable_telegram'] === true) {?>
    <?php echo '<script'; ?>
>
        $(document).ready(function () {
            var el = document.createElement('script');
            document.getElementById('telegram-login-box').append(el);
            el.onload = function () {
                $('#telegram-alert').remove()
            }
            el.src = 'https://telegram.org/js/telegram-widget.js?4';
            el.setAttribute('data-size', 'large')
            el.setAttribute('data-telegram-login', '<?php echo $_smarty_tpl->tpl_vars['telegram_bot']->value;?>
')
            el.setAttribute('data-auth-url', '<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/auth/telegram_oauth')
            el.setAttribute('data-request-access', 'write')
        });
    <?php echo '</script'; ?>
>
<?php }
}
}
