<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/shadowrocket.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0d51e5_57333608',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '29cee4041747bada95a35717eb53858de3823a7b' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/shadowrocket.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0d51e5_57333608 (Smarty_Internal_Template $_smarty_tpl) {
?>1：前往用户中心查看App Store账号，国区App Store已下架)

![](/images/c_ios_1.jpg)

2：打开App Store 切换账号，并下载App

![](/images/c_ios_2.jpg)

3：打开Safari，登录到 SSPANEL 的用户中心导入节点

![](/images/c_ios_3.jpg)

附加：iOS快速连接

![](/images/c_ios_4.jpg)<?php }
}
