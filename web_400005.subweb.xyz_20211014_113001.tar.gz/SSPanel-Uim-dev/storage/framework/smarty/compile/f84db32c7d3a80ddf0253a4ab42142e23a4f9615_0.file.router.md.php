<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/router.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0d7e31_18006734',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f84db32c7d3a80ddf0253a4ab42142e23a4f9615' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/router.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0d7e31_18006734 (Smarty_Internal_Template $_smarty_tpl) {
?>梅林

1. 下载并安装“科学上网”插件
2. 进入路由器管理页面->系统管理->勾选“Format JFFS partition at next boot”和“Enable JFFS custom scripts and configs”->应用本页面设置，重启路由器
3. 进入路由器管理页面->软件中心->离线安装，上传插件文件进行安装
4. 进入“科学上网”插件->更新管理，将下方的订阅地址复制粘贴进去，点击“保存并订阅”
5. 账号设置->节点选择，选择一个节点，打开“科学上网”开关->保存&应用

padavan：

1. 进入路由器管理页面->扩展功能->Shadowsocks
2. 将下方的订阅地址填入“ssr服务器订阅”，点击“更新”
3. 选择需要的节点（右方勾选）->应用主SS->打开上方的开关<?php }
}
