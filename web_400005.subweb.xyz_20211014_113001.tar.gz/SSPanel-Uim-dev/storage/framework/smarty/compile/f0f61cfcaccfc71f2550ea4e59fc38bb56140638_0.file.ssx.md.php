<?php
/* Smarty version 3.1.39, created on 2021-10-12 21:46:21
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/ssx.md' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616591ad0d94e2_77540731',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f0f61cfcaccfc71f2550ea4e59fc38bb56140638' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/markdown/ssx.md',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616591ad0d94e2_77540731 (Smarty_Internal_Template $_smarty_tpl) {
?>1. 下载 ShadowsocksX-NG并安装
2. 复制全部节点链接，然后右击托盘小飞机图标->从剪贴板导入服务器配置链接
3. 再次右击托盘小飞机图标->服务器，选择一个服务器即可上网<?php }
}
