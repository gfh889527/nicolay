<?php
/* Smarty version 3.1.39, created on 2021-10-12 17:25:15
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/node.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6165547b22ef33_82884899',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '11ceb24a6f42f6850d8558d3b259464107ed91c6' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/user/node.tpl',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:user/main.tpl' => 1,
    'file:dialog.tpl' => 1,
    'file:user/footer.tpl' => 1,
  ),
),false)) {
function content_6165547b22ef33_82884899 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->_tplFunction->registerTplFunctions($_smarty_tpl, array (
  'displayV2rayNode' => 
  array (
    'compiled_filepath' => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/storage/framework/smarty/compile/11ceb24a6f42f6850d8558d3b259464107ed91c6_0.file.node.tpl.php',
    'uid' => '11ceb24a6f42f6850d8558d3b259464107ed91c6',
    'call_name' => 'smarty_template_function_displayV2rayNode_6360777676165547b158a15_61468422',
  ),
  'displaySort13Node' => 
  array (
    'compiled_filepath' => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/storage/framework/smarty/compile/11ceb24a6f42f6850d8558d3b259464107ed91c6_0.file.node.tpl.php',
    'uid' => '11ceb24a6f42f6850d8558d3b259464107ed91c6',
    'call_name' => 'smarty_template_function_displaySort13Node_6360777676165547b158a15_61468422',
  ),
  'displaySort14Node' => 
  array (
    'compiled_filepath' => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/storage/framework/smarty/compile/11ceb24a6f42f6850d8558d3b259464107ed91c6_0.file.node.tpl.php',
    'uid' => '11ceb24a6f42f6850d8558d3b259464107ed91c6',
    'call_name' => 'smarty_template_function_displaySort14Node_6360777676165547b158a15_61468422',
  ),
  'displayNodeLink' => 
  array (
    'compiled_filepath' => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/storage/framework/smarty/compile/11ceb24a6f42f6850d8558d3b259464107ed91c6_0.file.node.tpl.php',
    'uid' => '11ceb24a6f42f6850d8558d3b259464107ed91c6',
    'call_name' => 'smarty_template_function_displayNodeLink_6360777676165547b158a15_61468422',
  ),
));
$_smarty_tpl->_subTemplateRender('file:user/main.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php echo '<script'; ?>
 src="//cdn.jsdelivr.net/gh/M1Screw/canvasjs.js@v3.2.8/canvasjs.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="application/x-javascript"> addEventListener("load", function () {
        setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
        window.scrollTo(0, 1);
    }
<?php echo '</script'; ?>
>






<main class="content">
    <div class="content-header ui-content-header">
        <div class="container">
            <h1 class="content-heading">节点列表</h1>
        </div>
    </div>
    <div class="container">
        <section class="content-inner margin-top-no">
            <div class="ui-card-wrap">
                <div class="row">
                    <div class="col-lg-12 col-sm-12 nodelist">

                        <div class="ui-switch node-switch">
                            <div class="card">
                                <div class="card-main">
                                    <div class="card-inner ui-switch-inner">
                                        <div class="switch-btn" id="switch-cards">
                                            <a href="#" onclick="return false">
                                                <i class="mdui-icon material-icons">apps</i>
                                            </a>
                                        </div>
                                        <div class="switch-btn" id="switch-table">
                                            <a href="#" onclick="return false">
                                                <i class="mdui-icon material-icons">dehaze</i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="node-cardgroup">
                    <?php $_smarty_tpl->_assignInScope('class', -1);?>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['nodes']->value, 'node', true);
$_smarty_tpl->tpl_vars['node']->iteration = 0;
$_smarty_tpl->tpl_vars['node']->index = -1;
$_smarty_tpl->tpl_vars['node']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['node']->value) {
$_smarty_tpl->tpl_vars['node']->do_else = false;
$_smarty_tpl->tpl_vars['node']->iteration++;
$_smarty_tpl->tpl_vars['node']->index++;
$_smarty_tpl->tpl_vars['node']->first = !$_smarty_tpl->tpl_vars['node']->index;
$_smarty_tpl->tpl_vars['node']->last = $_smarty_tpl->tpl_vars['node']->iteration === $_smarty_tpl->tpl_vars['node']->total;
$__foreach_node_0_saved = $_smarty_tpl->tpl_vars['node'];
?>
                        <?php if ($_smarty_tpl->tpl_vars['node']->value['class'] != $_smarty_tpl->tpl_vars['class']->value) {?>
                            <?php $_smarty_tpl->_assignInScope('class', $_smarty_tpl->tpl_vars['node']->value['class']);?>
                            <?php if (!$_smarty_tpl->tpl_vars['node']->first) {?></div><?php }?>
                        <div class="nodetitle">
                            <a class="waves-effect waves-button" data-toggle="collapse" href="#cardgroup<?php echo $_smarty_tpl->tpl_vars['class']->value;?>
" aria-expanded="true" aria-controls="cardgroup<?php echo $_smarty_tpl->tpl_vars['class']->value;?>
">
                                <span><?php if ($_smarty_tpl->tpl_vars['class']->value == 0) {?>普通<?php } else { ?>VIP <?php echo $_smarty_tpl->tpl_vars['node']->value['class'];?>
 <?php }?>用户节点</span>
                                <i class="material-icons">expand_more</i>
                            </a>
                        </div>
                        <div class="card-row collapse in" id="cardgroup<?php echo $_smarty_tpl->tpl_vars['class']->value;?>
">
                        <?php }?>
                            <div class="node-card node-flex" cardindex="<?php echo $_smarty_tpl->tpl_vars['node']->index;?>
">
                                <div class="nodemain">
                                    <div class="nodehead node-flex">
                                        <?php if ($_smarty_tpl->tpl_vars['config']->value['enable_flag'] === true) {?>
                                            <div class="flag">
                                                <img src="/images/prefix/<?php echo $_smarty_tpl->tpl_vars['node']->value['flag'];?>
">
                                            </div>
                                        <?php }?>
                                        <div class="nodename"><?php echo $_smarty_tpl->tpl_vars['node']->value['name'];?>
</div>
                                    </div>
                                    <!-- 在线人数 -->
                                    <div class="nodemiddle node-flex">
                                        <div class="onlinemember node-flex">
                                            <i class="material-icons node-icon">flight_takeoff</i>
                                            <span><?php if ($_smarty_tpl->tpl_vars['node']->value['online_user'] == -1) {?> N/A<?php } else { ?> <?php echo $_smarty_tpl->tpl_vars['node']->value['online_user'];
}?></span>
                                        </div>
                                        <div class="nodetype"><?php echo $_smarty_tpl->tpl_vars['node']->value['status'];?>
</div>
                                    </div>
                                    <div class="nodeinfo node-flex">
                                        <!-- 节点已用流量 -->
                                        <div class="nodetraffic node-flex">
                                            <i class="material-icons node-icon">equalizer</i>
                                            <span><?php if ($_smarty_tpl->tpl_vars['node']->value['traffic_limit'] > 0) {
echo $_smarty_tpl->tpl_vars['node']->value['traffic_used'];?>
/<?php echo $_smarty_tpl->tpl_vars['node']->value['traffic_limit'];?>
GB<?php } else {
echo $_smarty_tpl->tpl_vars['node']->value['traffic_used'];?>
GB<?php }?></span>
                                        </div>
                                        <!-- 节点流量倍率 -->
                                        <div class="nodecheck node-flex">
                                            <i class="material-icons node-icon">network_check</i>
                                            <span>x<?php echo $_smarty_tpl->tpl_vars['node']->value['traffic_rate'];?>
</span>
                                        </div>
                                        <!-- 节点速率 -->
                                        <div class="nodeband node-flex">
                                            <i class="material-icons node-icon">flash_on</i>
                                            <span><?php ob_start();
echo $_smarty_tpl->tpl_vars['node']->value['bandwidth'];
$_prefixVariable1 = ob_get_clean();
if ($_prefixVariable1 == 0) {?>N/A<?php } else {
echo $_smarty_tpl->tpl_vars['node']->value['bandwidth'];
}?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="nodestatus">
                                    <div class="<?php if ($_smarty_tpl->tpl_vars['node']->value['online'] == '1') {?>nodeonline<?php } elseif ($_smarty_tpl->tpl_vars['node']->value['online'] == '0') {?>nodeunset<?php } else { ?>nodeoffline<?php }?>">
                                        <i class="material-icons"><?php if ($_smarty_tpl->tpl_vars['node']->value['online'] == '1') {?>cloud_queue<?php } elseif ($_smarty_tpl->tpl_vars['node']->value['online'] == '0') {?>wifi_off<?php } else { ?>flash_off<?php }?></i>
                                    </div>
                                </div>
                            </div>
                            <div class="node-tip cust-model" tipindex="<?php echo $_smarty_tpl->tpl_vars['node']->index;?>
">
                                <?php if ($_smarty_tpl->tpl_vars['node']->value['class'] > $_smarty_tpl->tpl_vars['user']->value->class) {?>
                                    <p class="card-heading" align="center">
                                        <b>
                                            <i class="icon icon-lg">visibility_off</i>
                                            您当前等级不足以使用该节点，如需升级请<a href="/user/shop">点击这里</a>升级套餐
                                        </b>
                                    </p>
                                <?php } else { ?>
                                    <?php if (in_array($_smarty_tpl->tpl_vars['node']->value['sort'],array(0,10))) {?>
                                        <?php $_smarty_tpl->_assignInScope('relay_rule', null);?>

                                        <?php if ($_smarty_tpl->tpl_vars['node']->value['sort'] == 10) {?>
                                            <?php $_smarty_tpl->_assignInScope('relay_rule', $_smarty_tpl->tpl_vars['tools']->value->pick_out_relay_rule($_smarty_tpl->tpl_vars['node']->value['id'],$_smarty_tpl->tpl_vars['user']->value->port,$_smarty_tpl->tpl_vars['relay_rules']->value));?>
                                        <?php }?>
                                        <?php if ($_smarty_tpl->tpl_vars['node']->value['mu_only'] != 1) {?>
                                            <div class="tiptitle">
                                                <a href="javascript:void(0);" onClick="urlChange('<?php echo $_smarty_tpl->tpl_vars['node']->value['id'];?>
',0,<?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {
echo $_smarty_tpl->tpl_vars['relay_rule']->value->id;
} else { ?>0<?php }?>)">
                                                    <?php echo $_smarty_tpl->tpl_vars['node']->value['name'];
if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {?> - <?php echo $_smarty_tpl->tpl_vars['relay_rule']->value->dist_node()->name;
}?>
                                                </a>
                                                <div class="nodeload">
                                                    <div class="label label-brand-accent"> ↑点击节点查看配置信息</div>
                                                    <div>
                                                        <span class="node-icon"><i class="icon icon-lg">cloud</i></span>
                                                        <span class="node-load">负载：<code><?php if ($_smarty_tpl->tpl_vars['node']->value['latest_load'] == -1) {?>N/A<?php } else {
echo $_smarty_tpl->tpl_vars['node']->value['latest_load'];?>
%<?php }?></code></span>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php }?>
                                        <?php if ($_smarty_tpl->tpl_vars['node']->value['mu_only'] != -1) {?>
                                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['nodes_muport']->value, 'single_muport');
$_smarty_tpl->tpl_vars['single_muport']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['single_muport']->value) {
$_smarty_tpl->tpl_vars['single_muport']->do_else = false;
?>
                                                <?php if (!($_smarty_tpl->tpl_vars['single_muport']->value['server']->node_class <= $_smarty_tpl->tpl_vars['user']->value->class && ($_smarty_tpl->tpl_vars['single_muport']->value['server']->node_group == 0 || $_smarty_tpl->tpl_vars['single_muport']->value['server']->node_group == $_smarty_tpl->tpl_vars['user']->value->node_group))) {?>
                                                    <?php continue 1;?>
                                                <?php }?>
                                                <?php $_smarty_tpl->_assignInScope('relay_rule', null);?>
                                                <?php if ($_smarty_tpl->tpl_vars['node']->value['sort'] == 10 && $_smarty_tpl->tpl_vars['single_muport']->value['user']['is_multi_user'] != 2) {?>
                                                    <?php $_smarty_tpl->_assignInScope('relay_rule', $_smarty_tpl->tpl_vars['tools']->value->pick_out_relay_rule($_smarty_tpl->tpl_vars['node']->value['id'],$_smarty_tpl->tpl_vars['single_muport']->value['server']->server,$_smarty_tpl->tpl_vars['relay_rules']->value));?>
                                                <?php }?>
                                                <div class="tiptitle">
                                                    <a href="javascript:void(0);" onClick="urlChange('<?php echo $_smarty_tpl->tpl_vars['node']->value['id'];?>
',<?php echo $_smarty_tpl->tpl_vars['single_muport']->value['server']->server;?>
,<?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {
echo $_smarty_tpl->tpl_vars['relay_rule']->value->id;
} else { ?>0<?php }?>)"><?php echo $_smarty_tpl->tpl_vars['node']->value['name'];?>

                                                        <?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {?> - <?php echo $_smarty_tpl->tpl_vars['relay_rule']->value->dist_node()->name;
}?> -
                                                        单端口 Shadowsocks - <?php echo $_smarty_tpl->tpl_vars['node']->value['raw_node']->getOffsetPort($_smarty_tpl->tpl_vars['single_muport']->value['server']->server);?>
 端口
                                                    </a>
                                                </div>
                                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                        <?php }?>
                                    <?php } else { ?>
                                        <?php $_smarty_tpl->smarty->ext->_tplFunction->callTemplateFunction($_smarty_tpl, 'displayNodeLink', array('node'=>$_smarty_tpl->tpl_vars['node']->value), true);?>

                                    <?php }?>
                                    <div class="tipmiddle">
                                        <div>
                                            <span class="node-icon"><i class="icon icon-lg">chat</i> </span><?php echo $_smarty_tpl->tpl_vars['node']->value['info'];?>

                                        </div>
                                    </div>
                                    <?php if ($_smarty_tpl->tpl_vars['node']->value['sort'] == 11 || $_smarty_tpl->tpl_vars['node']->value['sort'] == 12) {?>
                                        <?php $_smarty_tpl->smarty->ext->_tplFunction->callTemplateFunction($_smarty_tpl, 'displayV2rayNode', array('node'=>$_smarty_tpl->tpl_vars['node']->value), true);?>

                                    <?php }?>

                                    <?php if ($_smarty_tpl->tpl_vars['node']->value['sort'] == 13) {?>
                                        <?php $_smarty_tpl->smarty->ext->_tplFunction->callTemplateFunction($_smarty_tpl, 'displaySort13Node', array('node'=>$_smarty_tpl->tpl_vars['node']->value), true);?>

                                    <?php }?>

                                    <?php if ($_smarty_tpl->tpl_vars['node']->value['sort'] == 14) {?>
                                        <?php $_smarty_tpl->smarty->ext->_tplFunction->callTemplateFunction($_smarty_tpl, 'displaySort14Node', array('node'=>$_smarty_tpl->tpl_vars['node']->value), true);?>

                                    <?php }?>
                                <?php }?>
                            </div>
                            <?php if ($_smarty_tpl->tpl_vars['node']->last) {?></div><?php }?>
                    <?php
$_smarty_tpl->tpl_vars['node'] = $__foreach_node_0_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </div>
                    <div class="card node-table">
                        <div class="card-main">
                            <div class="card-inner margin-bottom-no">
                                <div class="tile-wrap">
                                    <?php $_smarty_tpl->_assignInScope('class', -1);?>
                                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['nodes']->value, 'node', true);
$_smarty_tpl->tpl_vars['node']->iteration = 0;
$_smarty_tpl->tpl_vars['node']->index = -1;
$_smarty_tpl->tpl_vars['node']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['node']->value) {
$_smarty_tpl->tpl_vars['node']->do_else = false;
$_smarty_tpl->tpl_vars['node']->iteration++;
$_smarty_tpl->tpl_vars['node']->index++;
$_smarty_tpl->tpl_vars['node']->first = !$_smarty_tpl->tpl_vars['node']->index;
$_smarty_tpl->tpl_vars['node']->last = $_smarty_tpl->tpl_vars['node']->iteration === $_smarty_tpl->tpl_vars['node']->total;
$__foreach_node_2_saved = $_smarty_tpl->tpl_vars['node'];
?>
                                        <?php if ($_smarty_tpl->tpl_vars['node']->value['class'] != $_smarty_tpl->tpl_vars['class']->value) {?>
                                            <?php $_smarty_tpl->_assignInScope('class', $_smarty_tpl->tpl_vars['node']->value['class']);?>
                                            <p class="card-heading"><?php if ($_smarty_tpl->tpl_vars['class']->value == 0) {?>普通<?php } else { ?>VIP <?php echo $_smarty_tpl->tpl_vars['node']->value['class'];?>
 <?php }?>用户节点</p>
                                        <?php }?>
                                        <div class="tile tile-collapse">
                                            <div data-toggle="tile" data-target="#heading<?php echo $_smarty_tpl->tpl_vars['node']->value['id'];?>
">
                                                <div class="tile-side pull-left" data-ignore="tile">
                                                    <div class="avatar avatar-sm <?php if ($_smarty_tpl->tpl_vars['node']->value['online'] == '1') {?>nodeonline<?php } elseif ($_smarty_tpl->tpl_vars['node']->value['online'] == '0') {?>nodeunset<?php } else { ?>nodeoffline<?php }?>">
                                                        <span class="material-icons"><?php if ($_smarty_tpl->tpl_vars['node']->value['online'] == '1') {?>cloud_queue<?php } elseif ($_smarty_tpl->tpl_vars['node']->value['online'] == '0') {?>wifi_off<?php } else { ?>flash_off<?php }?></span>
                                                    </div>
                                                </div>
                                                <div class="tile-inner">
                                                    <div class="text-overflow node-textcolor">
                                                        <span class="enable-flag">
                                                            <?php if ($_smarty_tpl->tpl_vars['config']->value['enable_flag'] === true) {?>
                                                                <img src="/images/prefix/<?php echo $_smarty_tpl->tpl_vars['node']->value['flag'];?>
" height="22"
                                                                     width="40"/>
                                                            <?php }?>
                                                            <?php echo $_smarty_tpl->tpl_vars['node']->value['name'];?>

                                                        </span>
                                                        |
                                                        <span class="node-icon">
                                                            <i class="icon icon-lg">flight_takeoff</i></span>
                                                        <strong><b><span
                                                                        class="node-alive"><?php if ($_smarty_tpl->tpl_vars['node']->value['online_user'] == -1) {?>N/A<?php } else {
echo $_smarty_tpl->tpl_vars['node']->value['online_user'];
}?></span></b></strong>
                                                        | <span class="node-icon">
                                                            <i class="icon icon-lg">cloud</i></span>
                                                        <span class="node-load">负载：<?php if ($_smarty_tpl->tpl_vars['node']->value['latest_load'] == -1) {?>N/A<?php } else {
echo $_smarty_tpl->tpl_vars['node']->value['latest_load'];?>
%<?php }?></span>
                                                        | <span class="node-icon">
                                                            <i class="icon icon-lg">import_export</i></span>
                                                        <span class="node-mothed"><?php echo $_smarty_tpl->tpl_vars['node']->value['bandwidth'];?>
</span>
                                                        | <span class="node-icon"><i class="icon icon-lg">equalizer</i></span>
                                                        <?php if ($_smarty_tpl->tpl_vars['node']->value['traffic_limit'] > 0) {?>
                                                            <span class="node-band"><?php echo $_smarty_tpl->tpl_vars['node']->value['traffic_used'];?>
/<?php echo $_smarty_tpl->tpl_vars['node']->value['traffic_limit'];?>
</span>
                                                        <?php } else { ?>
                                                            <?php echo $_smarty_tpl->tpl_vars['node']->value['traffic_used'];?>
GB
                                                        <?php }?>
                                                        | <span class="node-icon">
                                                            <i class="icon icon-lg">network_check</i></span>
                                                        <span class="node-tr"><?php echo $_smarty_tpl->tpl_vars['node']->value['traffic_rate'];?>
 倍率</span>
                                                        | <span class="node-icon"><i class="icon icon-lg">notifications_none</i></span>
                                                        <span class="node-status"><?php echo $_smarty_tpl->tpl_vars['node']->value['status'];?>
</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="collapsible-region collapse" id="heading<?php echo $_smarty_tpl->tpl_vars['node']->value['id'];?>
">
                                                <div class="tile-sub">
                                                    <br>
                                                    <?php if ($_smarty_tpl->tpl_vars['node']->value['class'] > $_smarty_tpl->tpl_vars['user']->value->class) {?>
                                                        <div class="card">
                                                            <div class="card-main">
                                                                <div class="card-inner">
                                                                    <p class="card-heading" align="center"><b> <i
                                                                                    class="icon icon-lg">visibility_off</i>
                                                                            您当前等级不足以使用该节点，如需升级请<a
                                                                                    href="/user/shop">点击这里</a>升级套餐</b>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php } else { ?>
                                                        <div class="card nodetip-table">
                                                            <div class="card-main">
                                                                <div class="card-inner">
                                                        <?php if (in_array($_smarty_tpl->tpl_vars['node']->value['sort'],array(0,10))) {?>
                                                            <?php $_smarty_tpl->_assignInScope('relay_rule', null);?>
                                                            <!-- 用户等级不小于节点等级 -->
                                                            <?php if ($_smarty_tpl->tpl_vars['node']->value['sort'] == 10) {?>
                                                                <?php $_smarty_tpl->_assignInScope('relay_rule', $_smarty_tpl->tpl_vars['tools']->value->pick_out_relay_rule($_smarty_tpl->tpl_vars['node']->value['id'],$_smarty_tpl->tpl_vars['user']->value->port,$_smarty_tpl->tpl_vars['relay_rules']->value));?>
                                                            <?php }?>
                                                            <?php if ($_smarty_tpl->tpl_vars['node']->value['mu_only'] != 1) {?>
                                                                    <p class="card-heading">
                                                                        <a href="javascript:void(0);"
                                                                            onClick="urlChange('<?php echo $_smarty_tpl->tpl_vars['node']->value['id'];?>
',0,<?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {
echo $_smarty_tpl->tpl_vars['relay_rule']->value->id;
} else { ?>0<?php }?>)"><?php echo $_smarty_tpl->tpl_vars['node']->value['name'];?>

                                                                            <?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {?> - <?php echo $_smarty_tpl->tpl_vars['relay_rule']->value->dist_node()->name;
}?></a>
                                                                        <span class="label label-brand-accent">←点击节点查看配置信息</span>
                                                                    </p>
                                                            <?php }?>
                                                            <?php if ($_smarty_tpl->tpl_vars['node']->value['mu_only'] != -1) {?>
                                                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['nodes_muport']->value, 'single_muport');
$_smarty_tpl->tpl_vars['single_muport']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['single_muport']->value) {
$_smarty_tpl->tpl_vars['single_muport']->do_else = false;
?>
                                                                    <?php if (!($_smarty_tpl->tpl_vars['single_muport']->value['server']->node_class <= $_smarty_tpl->tpl_vars['user']->value->class && ($_smarty_tpl->tpl_vars['single_muport']->value['server']->node_group == 0 || $_smarty_tpl->tpl_vars['single_muport']->value['server']->node_group == $_smarty_tpl->tpl_vars['user']->value->node_group))) {?>
                                                                        <?php continue 1;?>
                                                                    <?php }?>
                                                                    <?php $_smarty_tpl->_assignInScope('relay_rule', null);?>
                                                                    <?php if ($_smarty_tpl->tpl_vars['node']->value['sort'] == 10 && $_smarty_tpl->tpl_vars['single_muport']->value['user']['is_multi_user'] != 2) {?>
                                                                        <?php $_smarty_tpl->_assignInScope('relay_rule', $_smarty_tpl->tpl_vars['tools']->value->pick_out_relay_rule($_smarty_tpl->tpl_vars['node']->value['id'],$_smarty_tpl->tpl_vars['single_muport']->value['server']->server,$_smarty_tpl->tpl_vars['relay_rules']->value));?>
                                                                    <?php }?>
                                                                    <p class="card-heading">
                                                                        <a href="javascript:void(0);"
                                                                           onClick="urlChange('<?php echo $_smarty_tpl->tpl_vars['node']->value['id'];?>
',<?php echo $_smarty_tpl->tpl_vars['single_muport']->value['server']->server;?>
,<?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {
echo $_smarty_tpl->tpl_vars['relay_rule']->value->id;
} else { ?>0<?php }?>)"><?php echo $_smarty_tpl->tpl_vars['node']->value['name'];?>

                                                                            <?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {?> - <?php echo $_smarty_tpl->tpl_vars['relay_rule']->value->dist_node()->name;
}?>
                                                                            - 单端口 Shadowsocks -
                                                                            <?php echo $_smarty_tpl->tpl_vars['node']->value['raw_node']->getOffsetPort($_smarty_tpl->tpl_vars['single_muport']->value['server']->server);?>

                                                                            端口</a><span
                                                                                class="label label-brand-accent">←点击节点查看配置信息</span>
                                                                    </p>
                                                                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                                            <?php }?>
                                                        <?php } else { ?>
                                                            <?php $_smarty_tpl->smarty->ext->_tplFunction->callTemplateFunction($_smarty_tpl, 'displayNodeLink', array('node'=>$_smarty_tpl->tpl_vars['node']->value), true);?>

                                                        <?php }?>
                                                                    <div>
                                                                        <i class="icon icon-lg node-icon">chat</i> <?php echo $_smarty_tpl->tpl_vars['node']->value['info'];?>

                                                                    </div>
                                                                    <?php if ($_smarty_tpl->tpl_vars['node']->value['sort'] == 11 || $_smarty_tpl->tpl_vars['node']->value['sort'] == 12) {?>
                                                                        <?php $_smarty_tpl->smarty->ext->_tplFunction->callTemplateFunction($_smarty_tpl, 'displayV2rayNode', array('node'=>$_smarty_tpl->tpl_vars['node']->value), true);?>

                                                                    <?php }?>
                                                                    <?php if ($_smarty_tpl->tpl_vars['node']->value['sort'] == 13) {?>
                                                                        <?php $_smarty_tpl->smarty->ext->_tplFunction->callTemplateFunction($_smarty_tpl, 'displaySort13Node', array('node'=>$_smarty_tpl->tpl_vars['node']->value), true);?>

                                                                    <?php }?>
                                                                    <?php if ($_smarty_tpl->tpl_vars['node']->value['sort'] == 14) {?>
                                                                        <?php $_smarty_tpl->smarty->ext->_tplFunction->callTemplateFunction($_smarty_tpl, 'displaySort14Node', array('node'=>$_smarty_tpl->tpl_vars['node']->value), true);?>

                                                                    <?php }?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php }?>
                                                    <?php if (!in_array($_smarty_tpl->tpl_vars['node']->value['sort'],array(1,2,5,9,999))) {?>
                                                        <?php $_smarty_tpl->_assignInScope('point_node', $_smarty_tpl->tpl_vars['node']->value);?>
                                                    <?php }?>
                                                    <?php if ((isset($_smarty_tpl->tpl_vars['point_node']->value))) {?>
                                                        <?php if ($_smarty_tpl->tpl_vars['point_node']->value != null) {?>
                                                            <div class="card">
                                                                <div class="card-main">
                                                                    <div class="card-inner" id="info<?php echo $_smarty_tpl->tpl_vars['node']->index;?>
">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <?php echo '<script'; ?>
>
                                                                $().ready(function () {
                                                                    $('#heading<?php echo $_smarty_tpl->tpl_vars['node']->value['id'];?>
').on("shown.bs.tile", function () {
                                                                        $("#info<?php echo $_smarty_tpl->tpl_vars['node']->index;?>
").load("/user/node/<?php echo $_smarty_tpl->tpl_vars['point_node']->value['id'];?>
/ajax");
                                                                    });
                                                                });
                                                            <?php echo '</script'; ?>
>
                                                        <?php }?>
                                                    <?php }?>
                                                </div>
                                            </div>
                                            <?php $_smarty_tpl->_assignInScope('point_node', null);?>
                                        </div>
                                    <?php
$_smarty_tpl->tpl_vars['node'] = $__foreach_node_2_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $_smarty_tpl->_subTemplateRender('file:dialog.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                <div aria-hidden="true" class="modal modal-va-middle fade" id="nodeinfo" role="dialog" tabindex="-1">
                    <div class="modal-dialog modal-full">
                        <div class="modal-content">
                            <iframe class="iframe-seamless" title="Modal with iFrame" id="infoifram"></iframe>
                        </div>
                    </div>
                </div>
        </section>
    </div>
</main>

<?php $_smarty_tpl->_subTemplateRender('file:user/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php echo '<script'; ?>
>
    function urlChange(id, is_mu, rule_id) {
        var site = `./node/${
                id
                }?ismu=${
                is_mu
                }&relay_rule=${
                rule_id
                }`;
        if (id == 'guide') {
            var doc = document.getElementById('infoifram').contentWindow.document;
            doc.open();
            doc.write('<img src="../images/node.gif" style="width: 100%;height: 100%; border: none;"/>');
            doc.close();
        } else {
            document.getElementById('infoifram').src = site;
        }
        $("#nodeinfo").modal();
    }
    $(function () {
        new ClipboardJS('.copy-text');
    });
    $(".copy-text").click(function () {
        $("#result").modal();
        $$.getElementById('msg').innerHTML = '已复制，请进入软件添加。';
    });
    
    ;(function () {
        'use strict'
        //箭头旋转
        let rotateTrigger = document.querySelectorAll('a[href^="#cardgroup"]');
        let arrows = document.querySelectorAll('a[href^="#cardgroup"] i')

        for (let i = 0; i < rotateTrigger.length; i++) {
            rotatrArrow(rotateTrigger[i], arrows[i]);
        }
        //UI切换
        let elNodeCard = $$.querySelectorAll(".node-cardgroup");
        let elNodeTable = $$.querySelectorAll(".node-table");
        let switchToCard = new UIswitch('switch-cards', elNodeTable, elNodeCard, 'grid', 'tempnode');
        switchToCard.listenSwitch();
        let switchToTable = new UIswitch('switch-table', elNodeCard, elNodeTable, 'flex', 'tempnode');
        switchToTable.listenSwitch();
        switchToCard.setDefault();
        switchToTable.setDefault();
        //遮罩
        let buttongroup = document.querySelectorAll('.node-card');
        let modelgroup = document.querySelectorAll('.node-tip');
        for (let i = 0; i < buttongroup.length; i++) {
            custModal(buttongroup[i], modelgroup[i]);
        }
    })();
    
<?php echo '</script'; ?>
><?php }
/* smarty_template_function_displayV2rayNode_6360777676165547b158a15_61468422 */
if (!function_exists('smarty_template_function_displayV2rayNode_6360777676165547b158a15_61468422')) {
function smarty_template_function_displayV2rayNode_6360777676165547b158a15_61468422(Smarty_Internal_Template $_smarty_tpl,$params) {
$params = array_merge(array('node'=>null), $params);
foreach ($params as $key => $value) {
$_smarty_tpl->tpl_vars[$key] = new Smarty_Variable($value, $_smarty_tpl->isRenderingCache);
}
?>

    <?php $_smarty_tpl->_assignInScope('v2server', $_smarty_tpl->tpl_vars['node']->value['raw_node']->getV2RayItem($_smarty_tpl->tpl_vars['user']->value));?>
    <p>节点地址：<span class="card-tag tag-blue"><?php echo $_smarty_tpl->tpl_vars['v2server']->value['add'];?>
</span></p>
    <p>节点端口：<span class="card-tag tag-volcano"><?php echo $_smarty_tpl->tpl_vars['v2server']->value['port'];?>
</span></p>
    <p>AlterId：<span class="card-tag tag-purple"><?php echo $_smarty_tpl->tpl_vars['v2server']->value['aid'];?>
</span></p>
    <p>UUID：<span class="card-tag tag-geekblue"><?php echo $_smarty_tpl->tpl_vars['user']->value->getUuid();?>
</span></p>
    <p>传输协议：<span class="card-tag tag-green"><?php echo $_smarty_tpl->tpl_vars['v2server']->value['net'];?>
</span></p>
    <?php if ($_smarty_tpl->tpl_vars['v2server']->value['net'] == 'ws') {?>
        <p>伪装路径：<span class="card-tag tag-green"><?php echo $_smarty_tpl->tpl_vars['v2server']->value['path'];?>
</span></p>
        <p>HOST：<span class="card-tag tag-green"><?php echo $_smarty_tpl->tpl_vars['v2server']->value['host'];?>
</span></p>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['v2server']->value['net'] == 'kcp') {?>
        <p>伪装方式：<span class="card-tag tag-green"><?php echo $_smarty_tpl->tpl_vars['v2server']->value['type'];?>
</span></p>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['v2server']->value['tls'] == 'tls') {?>
        <p>TLS：<span class="card-tag tag-green">TLS</span></p>
    <?php }?>

    <p>V2RayN 链接：
        <a class="copy-text" data-clipboard-text="<?php echo App\Utils\URL::getV2Url($_smarty_tpl->tpl_vars['user']->value,$_smarty_tpl->tpl_vars['node']->value['raw_node']);?>
">点击复制</a>
    </p>
<?php
}}
/*/ smarty_template_function_displayV2rayNode_6360777676165547b158a15_61468422 */
/* smarty_template_function_displaySort13Node_6360777676165547b158a15_61468422 */
if (!function_exists('smarty_template_function_displaySort13Node_6360777676165547b158a15_61468422')) {
function smarty_template_function_displaySort13Node_6360777676165547b158a15_61468422(Smarty_Internal_Template $_smarty_tpl,$params) {
$params = array_merge(array('node'=>null), $params);
foreach ($params as $key => $value) {
$_smarty_tpl->tpl_vars[$key] = new Smarty_Variable($value, $_smarty_tpl->isRenderingCache);
}
?>

    <?php $_smarty_tpl->_assignInScope('sort13Node', $_smarty_tpl->tpl_vars['node']->value['raw_node']->getV2RayPluginItem($_smarty_tpl->tpl_vars['user']->value));?>
    <?php if ($_smarty_tpl->tpl_vars['sort13Node']->value === null) {?>
        <p>您的加密方式非 AEAD 系列，无法使用此节点.</p>
    <?php } else { ?>
        <p>节点地址：<span class="card-tag tag-blue"><?php echo $_smarty_tpl->tpl_vars['sort13Node']->value['address'];?>
</span></p>
        <p>节点端口：<span class="card-tag tag-volcano"><?php echo $_smarty_tpl->tpl_vars['sort13Node']->value['port'];?>
</span></p>
        <p>节点加密：<span class="card-tag tag-purple"><?php echo $_smarty_tpl->tpl_vars['sort13Node']->value['method'];?>
</span></p>
        <p>连接密码：<span class="card-tag tag-geekblue"><?php echo $_smarty_tpl->tpl_vars['sort13Node']->value['passwd'];?>
</span></p>
        <p>混淆方式：<span class="card-tag tag-green"><?php echo $_smarty_tpl->tpl_vars['sort13Node']->value['obfs'];?>
</span></p>
        <p>混淆参数：<span class="card-tag tag-volcano"><?php echo $_smarty_tpl->tpl_vars['sort13Node']->value['obfs_param'];?>
</span></p>
    <?php }
}}
/*/ smarty_template_function_displaySort13Node_6360777676165547b158a15_61468422 */
/* smarty_template_function_displaySort14Node_6360777676165547b158a15_61468422 */
if (!function_exists('smarty_template_function_displaySort14Node_6360777676165547b158a15_61468422')) {
function smarty_template_function_displaySort14Node_6360777676165547b158a15_61468422(Smarty_Internal_Template $_smarty_tpl,$params) {
$params = array_merge(array('node'=>null), $params);
foreach ($params as $key => $value) {
$_smarty_tpl->tpl_vars[$key] = new Smarty_Variable($value, $_smarty_tpl->isRenderingCache);
}
?>

    <?php $_smarty_tpl->_assignInScope('sort14Node', $_smarty_tpl->tpl_vars['node']->value['raw_node']->getTrojanItem($_smarty_tpl->tpl_vars['user']->value));?>
    <p>节点地址：<span class="card-tag tag-blue"><?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['address'];?>
</span></p>
    <p>节点端口：<span class="card-tag tag-volcano"><?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['port'];?>
</span></p>
    <p>连接密码：<span class="card-tag tag-geekblue"><?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['passwd'];?>
</span></p>
    <?php if ($_smarty_tpl->tpl_vars['sort14Node']->value['host'] != $_smarty_tpl->tpl_vars['sort14Node']->value['address']) {?>
        <p>HOST&PEER：<span class="card-tag tag-green"><?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['host'];?>
</span></p>
    <?php }?>
    <?php if ($_smarty_tpl->tpl_vars['sort14Node']->value['host'] != $_smarty_tpl->tpl_vars['sort14Node']->value['address']) {?>
    <p>Trojan 链接：
        <a class="copy-text" data-clipboard-text="trojan://<?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['passwd'];?>
@<?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['address'];?>
:<?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['port'];?>
?peer=<?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['host'];?>
&sni=<?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['host'];?>
#<?php echo rawurlencode($_smarty_tpl->tpl_vars['node']->value['name']);?>
">点击复制</a>
    </p>
    <?php } else { ?>
    <p>Trojan 链接：
        <a class="copy-text" data-clipboard-text="trojan://<?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['passwd'];?>
@<?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['address'];?>
:<?php echo $_smarty_tpl->tpl_vars['sort14Node']->value['port'];?>
#<?php echo rawurlencode($_smarty_tpl->tpl_vars['node']->value['name']);?>
">点击复制</a>
    </p>
    <?php }
}}
/*/ smarty_template_function_displaySort14Node_6360777676165547b158a15_61468422 */
/* smarty_template_function_displayNodeLink_6360777676165547b158a15_61468422 */
if (!function_exists('smarty_template_function_displayNodeLink_6360777676165547b158a15_61468422')) {
function smarty_template_function_displayNodeLink_6360777676165547b158a15_61468422(Smarty_Internal_Template $_smarty_tpl,$params) {
$params = array_merge(array('node'=>null), $params);
foreach ($params as $key => $value) {
$_smarty_tpl->tpl_vars[$key] = new Smarty_Variable($value, $_smarty_tpl->isRenderingCache);
}
?>

    <div class="tiptitle">
        <a href="javascript:void(0);"><?php echo $_smarty_tpl->tpl_vars['node']->value['name'];?>
</a>
    </div>
<?php
}}
/*/ smarty_template_function_displayNodeLink_6360777676165547b158a15_61468422 */
}
