<?php
/* Smarty version 3.1.39, created on 2021-10-13 11:16:40
  from '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/500.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61664f9864c6d2_46798206',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '01d231cac870df36eb15c97a61fa0aaabda78d27' => 
    array (
      0 => '/www/wwwroot/400005.subweb.xyz/SSPanel-Uim-dev/resources/views/material/500.tpl',
      1 => 1612924517,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61664f9864c6d2_46798206 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE HTML>
<html lang="zh-cn">
<head>
    <title>该网页无法正常运作 - <?php echo $_smarty_tpl->tpl_vars['config']->value['appName'];?>
</title>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>
    <meta charset="utf-8"/>
    <link rel="shortcut icon" href="/favicon.ico"/>
    <link rel="bookmark" href="/favicon.ico" type="image/x-icon"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>
    <link rel="shortcut icon" type="image/ico" href="images/ssr.ico">
    <link rel="stylesheet" href="/assets/css/main.min.css"/>
    <noscript>
        <link rel="stylesheet" href="/assets/css/noscript.min.css"/>
    </noscript>
</head>

<body>

<div id="wrapper">
    <header id="header">
        <div class="logo">
            <span class="icon fa-rocket"></span>
        </div>
        <div class="content">
            <div class="inner">
                <h1>500 错误</h1>
                <p>服务娘崩溃了呢... TwT</p>
                <p>这件事儿不应该发生的...如果反复出现可以提交一下工单联系站主.</p>
                <?php if (!is_null($_smarty_tpl->tpl_vars['exceptionId']->value)) {?>
                <p>事件 ID: <?php echo $_smarty_tpl->tpl_vars['exceptionId']->value;?>
</p>
                <?php }?>
            </div>
        </div>
        <nav>
            <ul>
                <li><a href="./#">返回首页</a></li>
            </ul>
        </nav>
    </header>
    <footer id="footer">
        <p class="copyright">&copy;<?php echo date("Y");?>
 <?php echo $_smarty_tpl->tpl_vars['config']->value['appName'];?>
 </p>
    </footer>
</div>
<div id="bg"></div>

<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/jquery@3.5.1"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/gh/ajlkn/skel@3.0.1/dist/skel.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/assets/js/util.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/assets/js/main.min.js"><?php echo '</script'; ?>
>

<?php if (!is_null($_smarty_tpl->tpl_vars['exceptionId']->value)) {
echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/@sentry/browser@5.20.1/build/bundle.min.js" integrity="sha256-EIV/iYkbXFgnuIHEdltBOK4eY58n87ADisyDI8/VJPg=" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    Sentry.init({
        dsn: "<?php echo $_smarty_tpl->tpl_vars['config']->value['sentry_dsn'];?>
"
    });
    Sentry.showReportDialog({
        eventId: '<?php echo $_smarty_tpl->tpl_vars['exceptionId']->value;?>
',
        user: {
            name: '<?php echo $_smarty_tpl->tpl_vars['user']->value->user_name;?>
',
            email: '<?php echo $_smarty_tpl->tpl_vars['user']->value->email;?>
'
        }
    });
<?php echo '</script'; ?>
>
<?php }?>

</body>

</html>
<?php }
}
