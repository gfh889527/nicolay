梅林：

1. 下载“科学上网”插件
2. 进入路由器管理页面->系统管理->勾选“Format JFFS partition at next boot”和“Enable JFFS custom scripts and configs”->应用本页面设置，重启路由器
3. 进入路由器管理页面->软件中心->离线安装，上传插件文件进行安装
4. 进入“科学上网”插件->节点管理，手动添加节点，打开“科学上网”开关->保存&应用

padavan：

1. 进入路由器管理页面->扩展功能->Shadowsocks
2. 手动添加需要的节点并勾选->应用主SS->打开上方的开关