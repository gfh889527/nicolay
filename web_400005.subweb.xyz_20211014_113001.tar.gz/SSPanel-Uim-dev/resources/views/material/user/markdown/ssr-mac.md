1：把下载的DMG包放入应用程序列表

![](/images/c_mac_1.png)

2：打开程式

![](/images/c_mac_2.png)

3：如提示不安全，请到系统偏好设置打开程式

![](/images/c_mac_3.png)

4：服务器-编辑订阅

![](/images/c_mac_4.png)

5：点击+号后填入订阅链接后手动更新订阅

![](/images/c_mac_5.png)

![](/images/c_mac_4.png)

6：选择一个节点

![](/images/c_mac_6.png)

7：打开谷歌测试一下吧

![](/images/c_mac_7.png)