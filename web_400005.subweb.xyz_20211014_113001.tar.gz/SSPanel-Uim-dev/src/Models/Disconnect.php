<?php

namespace App\Models;

/**
 * Disconnect Model
 */
class Disconnect extends Model
{
    protected $connection = 'default';
    protected $table = 'disconnect_ip';
}
